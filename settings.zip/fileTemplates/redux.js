import { configureStore } from '@reduxjs/toolkit';
import ${sliceName} from "./slices/${sliceName}Slice";


export const store = configureStore({
  reducer: {
  ${sliceName}
  }
  ,
});