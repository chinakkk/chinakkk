import styles from './${name}.module.scss'
import {FC} from "react"

type ${name}Props={

}

const ${name} : FC= () => {
    return (
        <div className={styles.container}>
            
        </div>
    ) 
}
export default ${name};