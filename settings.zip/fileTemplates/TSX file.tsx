import styles from './${name}.module.scss'
import {FC} from "react"

type ${name}Props={

}

const ${name} : FC= () => {
    return (
        <div>
            
        </div>
    ) 
}
export default ${name};