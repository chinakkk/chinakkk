import {createSlice} from "@reduxjs/toolkit";

const initialState = {
  
}

const ${sliceName}Slice=createSlice({
  name:'${sliceName}',
  initialState,
  reducers:{
   
  }
})

export const {}=${sliceName}Slice.actions
export default ${sliceName}Slice.reducer