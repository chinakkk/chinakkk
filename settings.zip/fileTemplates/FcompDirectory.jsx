import styles from './${nameFuncComp}.module.scss'

const ${nameFuncComp} = () => {
    return (
        <div className={styles.container}>
            
        </div>
    ) 
}
export default ${nameFuncComp};