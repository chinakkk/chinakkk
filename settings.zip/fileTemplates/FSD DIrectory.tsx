import { FC } from "react";
import styles from "./${name}.module.scss";

type ${name}Props={

}

export const ${name}: FC = () => {
  return <div className={styles.container}></div>;
};
