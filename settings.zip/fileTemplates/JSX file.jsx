const ${Name} = () => {
    return (
        <div>
            
        </div>
    )
}
export default ${Name};  