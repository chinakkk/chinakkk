export const ${exportName} = () => {
    
}